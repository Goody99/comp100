<?php

		require_once (dirname(__FILE__) . '/secret.php');

		$host = $connection_details['host'];
		$dbname = $connection_details['database'];
		$username = $connection_details['username'];
		$password = $connection_details['password'];
		
	


	// connection to DB
	try {
		$dbh = new PDO("mysql:host={$host};dbname={$dbname}", $username, $password);
		$dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	} catch (PDOException $e) {
		echo 'Connection failed: ' . $e->getMessage();
	}

?>