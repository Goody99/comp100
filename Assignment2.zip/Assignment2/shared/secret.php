<?php

	$connection_details = [
		"host" => "us-cdbr-azure-southcentral-e.cloudapp.net",
		"username" => "b2a34cbae7f794",
		"password" => "bfca5a3f",
		"database" => "acsm_39ce1a111bc6f00"
	]

?>